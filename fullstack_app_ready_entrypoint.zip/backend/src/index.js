require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { PrismaClient } = require('@prisma/client');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');

const prisma = new PrismaClient();
const app = express();
const PORT = process.env.PORT || 4000;

app.use(bodyParser.json({ verify: (req, res, buf) => { req.rawBody = buf } }));
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || true }));
app.use('/static', express.static('../frontend'));

// helper middleware: auth
function authMiddleware(req, res, next){
  const header = req.headers.authorization;
  if(!header) return res.status(401).json({ error: 'Missing token' });
  const token = header.split(' ')[1];
  try{
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'replace_this');
    req.user = payload;
    next();
  }catch(e){
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Routes: health
app.get('/api/health', (req,res)=>res.json({ ok:true, time: new Date() }));

// Auth: register/login
app.post('/api/auth/register', async (req,res)=>{
  const { email, password, name } = req.body;
  if(!email || !password) return res.status(400).json({ error: 'Email and password required' });
  const hashed = await bcrypt.hash(password, 10);
  try{
    const user = await prisma.user.create({ data: { email, password: hashed, name } });
    const token = jwt.sign({ userId: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET || 'replace_this', { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  }catch(e){
    return res.status(400).json({ error: 'Email already in use' });
  }
});

app.post('/api/auth/login', async (req,res)=>{
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ userId: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET || 'replace_this', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
});

// Create some seed rooms if none
async function ensureRooms(){
  const count = await prisma.room.count();
  if(count === 0){
    await prisma.room.createMany({ data: [
      { key: 'cabin', title: 'Cabin', price: 200000 },
      { key: 'vip', title: 'VIP Room', price: 500000 }
    ]});
    console.log('Seeded rooms');
  }
}

// Auth: get current user from token
app.get('/api/auth/me', authMiddleware, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user.userId }, select: { id: true, email: true, name: true, role: true, createdAt: true } });
    if(!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

ensureRooms().catch(console.error);

// Bookings
app.post('/api/bookings', async (req,res)=>{
  try{
    const { name, phone, room, durasi, total } = req.body;
    if(!name || !phone || !room) return res.status(400).json({ error: 'Missing fields' });
    const roomRec = await prisma.room.findUnique({ where: { key: room } });
    if(!roomRec) return res.status(400).json({ error: 'Unknown room' });
    const booking = await prisma.booking.create({ data: { name, phone, durasi: durasi||1, total: total || roomRec.price, roomId: roomRec.id } });
    res.json(booking);
  }catch(e){
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin: list bookings (auth required & role check)
app.get('/api/bookings', authMiddleware, async (req,res)=>{
  try{
    // only admin allowed to fetch all bookings; normal users can only fetch their own if implemented
    if(req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const list = await prisma.booking.findMany({ include: { room: true, payment: true } , orderBy: { createdAt: 'desc' } });
    res.json(list);
  }catch(e){ console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// payments: create payment intent (Stripe) for a booking
app.post('/api/payments/create-payment-intent', async (req,res)=>{
  try{
    const { bookingId, currency } = req.body;
    if(!bookingId) return res.status(400).json({ error: 'bookingId required' });
    const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
    if(!booking) return res.status(400).json({ error: 'Booking not found' });
    // Use server-side trusted amount from booking.total
    const amount = booking.total;
    // create Stripe PaymentIntent (amount should be in the smallest currency unit)
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount,
      currency: currency || 'usd',
      metadata: { bookingId: String(bookingId) }
    });
    // store minimal payment record
    const pay = await prisma.payment.create({
      data: { bookingId: booking.id, stripeId: paymentIntent.id, amount: amount, currency: currency || 'usd', status: paymentIntent.status }
    });
    res.json({ clientSecret: paymentIntent.client_secret, paymentId: pay.id });
  }catch(e){ console.error(e); res.status(500).json({ error: 'Server error', details: String(e) }); }
});

// Stripe webhook endpoint to update payment status (configure endpoint in Stripe dashboard)
app.post('/api/payments/webhook', express.raw({type: 'application/json'}), async (req,res)=>{
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event = null;
  try{
    if(webhookSecret){
      // verify signature using Stripe SDK
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } else {
      // fallback (unsafe) parsing when webhook secret not provided (development)
      event = JSON.parse(req.body.toString());
    }
  }catch(err){
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  // Handle the event types you care about
  if(event.type === 'payment_intent.succeeded'){
    const pi = event.data.object;
    const stripeId = pi.id;
    // mark payment as succeeded and booking paid
    try{
      const p = await prisma.payment.update({ where: { stripeId }, data: { status: 'succeeded' } });
      await prisma.booking.update({ where: { id: p.bookingId }, data: { paid: true } });
    }catch(e){ console.error(e); }
  }
  res.json({ received: true });
});

// start
app.listen(PORT, ()=> console.log(`API running on port ${PORT}`));
