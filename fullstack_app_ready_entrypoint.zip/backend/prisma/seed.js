const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

const prisma = new PrismaClient();

async function main(){
  // create rooms if none
  const rooms = [
    { key: 'cabin', title: 'Cabin', price: 200000 },
    { key: 'vip', title: 'VIP Room', price: 500000 }
  ];
  for(const r of rooms){
    const exists = await prisma.room.findUnique({ where: { key: r.key } });
    if(!exists){
      await prisma.room.create({ data: r });
      console.log('Created room', r.key);
    }
  }

  // create admin user if not exists
  const adminEmail = process.env.SEED_ADMIN_EMAIL || 'admin@example.com';
  const adminPass = process.env.SEED_ADMIN_PASSWORD || 'adminpassword';
  const admin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if(!admin){
    const hashed = await bcrypt.hash(adminPass, 10);
    await prisma.user.create({ data: { email: adminEmail, password: hashed, name: 'Administrator', role: 'admin' }});
    console.log('Created admin user', adminEmail);
  } else {
    console.log('Admin user exists:', adminEmail);
  }
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
