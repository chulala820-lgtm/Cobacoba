#!/bin/sh
set -e

echo "Entrypoint: waiting for database to be available..."

# Try running prisma migrate deploy until success or timeout
MAX_RETRIES=${MAX_RETRIES:-30}
SLEEP_SECONDS=${SLEEP_SECONDS:-2}
i=0
until npx prisma migrate deploy; do
  i=$((i+1))
  if [ "$i" -ge "$MAX_RETRIES" ]; then
    echo "Max retries reached while waiting for DB migrations. Exiting."
    exit 1
  fi
  echo "Prisma migrate failed, retrying in ${SLEEP_SECONDS}s... ($i/$MAX_RETRIES)"
  sleep ${SLEEP_SECONDS}
done

echo "Prisma migrate succeeded (or no migrations needed). Generating client..."
npx prisma generate || true

echo "Running seed script (if any)"
node prisma/seed.js || echo "Seed script exited with non-zero status, continuing..."

echo "Starting application..."
exec node src/index.js
